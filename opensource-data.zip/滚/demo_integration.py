# demo_integration.py
from opensoda_enhancer import OpenSODAEnhancer

 
print("SQLBot + 我的模型 整合演示")
 

# 4个SQLBot结果
sqlbot_results = [
    {
        'name': '活跃度排名',
        'data': {
            'pytorch/pytorch': 3581.6,
            'facebook/react': 1041.86,
            'vuejs/vue': 460.26,
            'torvalds/linux': 100.08
        }
    },
    {
        'name': '巴士因子排名', 
        'data': {
            'torvalds/linux': 28.8,
            'vuejs/vue': 179.3,
            'facebook/react': 319.7,
            'pytorch/pytorch': 358.6
        }
    },
    {
        'name': '代码变更排名',
        'data': {
            'pytorch/pytorch': 35131263,
            'facebook/react': 7681434,
            'torvalds/linux': 3959250,
            'vuejs/vue': 1230831
        }
    },
    {
        'name': '新贡献者排名',
        'data': {
            'facebook/react': 27.196428571428573,
            'pytorch/pytorch': 16.60655737704918,
            'vuejs/vue': 10.606299212598426,
            'torvalds/linux': 1.0
        }
    }
]

enhancer = OpenSODAEnhancer()

print("原始SQLBot查询结果:")
for i, result in enumerate(sqlbot_results, 1):
    print(f"{i}. {result['name']}")

 


for result in sqlbot_results:
    enhanced = enhancer.enhance(result)
    
    print(f"查询: {enhanced['original_query']}")
    
   
    if enhanced.get('enhanced_analysis'):
        for item in enhanced['enhanced_analysis']:
            project = item['project']
            
            print(f"  {project}:")
            
            if 'activity' in item:
                print(f"    值: {item['activity']}")
                print(f"    分析: {item['your_analysis']}")
                print(f"    关键因素: {item['key_factor']}")
                
            elif 'bus_factor' in item:
                print(f"    值: {item['bus_factor']}")
                print(f"    风险评估: {item['risk_assessment']}")
                print(f"    建议措施: {item['recommended_action']}")
                
            elif 'code_changes' in item:
                print(f"    值: {item['code_changes']:,} 行")
                print(f"    生产力: {item['productivity_assessment']}")
                print(f"    关注点: {item['focus_area']}")
                
            elif 'new_contributors' in item:
                print(f"    值: {item['new_contributors']:.1f} 人/月")
                print(f"    增长评估: {item['growth_assessment']}")
                print(f"    增长策略: {item['growth_strategy']}")
            
            print()  

 
print("SQLBot提供实时数据 + 我的模型提供深度分析")
 