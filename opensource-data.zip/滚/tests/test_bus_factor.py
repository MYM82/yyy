# test_bus_factor.py
from opensoda_enhancer import OpenSODAEnhancer

# 第二个SQLBot结果
sqlbot_results = {
    'name': '巴士因子排名',
    'data': {
        'torvalds/linux': 28.8,
        'vuejs/vue': 179.3,
        'facebook/react': 319.7,
        'pytorch/pytorch': 358.6
    }
}

enhancer = OpenSODAEnhancer()
 
enhanced = enhancer.enhance(sqlbot_results)

print(f"\n原始查询: {enhanced['original_query']}")
print(f"模型精度: R²={enhanced['model_info']['r2_score']}")

print("\n 风险增强分析结果:")
for item in enhanced['enhanced_analysis']:
    print(f"  {item['project']}:")
    print(f"    巴士因子: {item['bus_factor']}")
    print(f"    风险评估: {item['risk_assessment']}")
    print(f"    建议措施: {item['recommended_action']}")
    print()