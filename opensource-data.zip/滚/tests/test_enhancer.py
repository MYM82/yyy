# test_enhancer.py
from opensoda_enhancer import OpenSODAEnhancer


sqlbot_results = {
    'name': '活跃度排名',
    'data': {
        'pytorch/pytorch': 3581.6,
        'facebook/react': 1041.86,
        'vuejs/vue': 460.26,
        'torvalds/linux': 100.08
    }
}

enhancer = OpenSODAEnhancer()

print("测试增强器（活跃度分析）...")
enhanced = enhancer.enhance(sqlbot_results)

print(f"\n原始查询: {enhanced['original_query']}")
print(f"模型精度: R²={enhanced['model_info']['r2_score']}")

print("\n 增强分析结果:")
for item in enhanced['enhanced_analysis']:
    print(f"  {item['project']}:")
    print(f"    活跃度: {item['activity']}")
    print(f"    我的分析: {item['your_analysis']}")
    print(f"    关键因素: {item['key_factor']}")
    print()