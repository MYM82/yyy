  
 
import json
import pandas as pd
import os

def safe_float_convert(value):

    if value is None:
        return None
    elif isinstance(value, dict):
         
        return float(value.get('avg', 0)) if value.get('avg') is not None else None
    elif isinstance(value, (int, float)):
        return float(value)
    else:
        try:
            return float(value)
        except:
            return None

def process_single_file(filepath):
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = json.load(f)
        
       
        if not isinstance(content, dict):
            return []
        
     
        repo_name = content.get('repo')
        metric_name = content.get('metric')
        
        if not repo_name or not metric_name:
            return []
        
         
        time_series = content.get('data', {})
        if not isinstance(time_series, dict):
            return []
        
        records = []
        for month_str, value in time_series.items():
           
            try:
                
                month = pd.to_datetime(month_str, format='%Y-%m')
            except:
                try:
                  
                    month = pd.to_datetime(month_str)
                except:
                    continue
            
            
            numeric_value = safe_float_convert(value)
            
            records.append({
                'repo': repo_name,
                'month': month,
                'month_str': month_str,
                'metric': metric_name,
                'value': numeric_value
            })
        
        return records
        
    except Exception as e:
        print(f"  处理文件 {os.path.basename(filepath)} 时出错: {e}")
        return []

def main():
     
    
    data_dir = "test_data"
    
    
    
    json_files = [f for f in os.listdir(data_dir) if f.endswith('.json')]
    
    all_records = []
    for i, filename in enumerate(json_files, 1):
        filepath = os.path.join(data_dir, filename)
        records = process_single_file(filepath)
        all_records.extend(records)
        
    
    
    df_long = pd.DataFrame(all_records)
    
    initial_count = len(df_long)
    df_long = df_long[~df_long['month'].isna()].copy()
    final_count = len(df_long)
    
    df_wide = df_long.pivot_table(
        index=['repo', 'month', 'month_str'],
        columns='metric',
        values='value',
        aggfunc='first'   
    ).reset_index()

    df_wide.columns.name = None
     
    column_mapping = {
        'accepted': 'change_requests_accepted',
        'closed': 'issues_closed', 
        'contributors': 'new_contributors',
        'factor': 'bus_factor',
        'fork': 'technical_fork',
        'new': 'issues_new',
        'requests': 'change_requests',
        'reviews': 'change_requests_reviews',
        'sum': 'code_change_lines_sum',
        'time': 'issue_response_time'
    }
    
     
    df_wide = df_wide.rename(columns=column_mapping)
    
   
    df_wide = df_wide.sort_values(['repo', 'month']).reset_index(drop=True)
    
     
    
    print(f"1. 数据形状: {df_wide.shape} (行数 × 列数)")
    print(f"2. 包含项目: {len(df_wide['repo'].unique())} 个")
    
    
    real_repos = [repo for repo in df_wide['repo'].unique() 
                  if '/' in repo and repo.count('/') == 1]
    print(f"   真实项目: {real_repos}")
    
    print(f"3. 时间范围: {df_wide['month'].min().strftime('%Y-%m')} 到 {df_wide['month'].max().strftime('%Y-%m')}")
    

    all_columns = df_wide.columns.tolist()
    metric_cols = [col for col in all_columns if col not in ['repo', 'month', 'month_str']]
    print(f"4. 可用指标 ({len(metric_cols)} 个):")
    for col in metric_cols:
        non_null = df_wide[col].count()
        print(f"   - {col}: {non_null} 个非空值")
    
   
    output_file = "analysis_base_FIXED.csv"
    df_wide.to_csv(output_file, index=False, encoding='utf-8')
    print(f"\n  {output_file}")
    
     
    print("\n 数据预览:")
    print(df_wide[['repo', 'month', 'activity', 'openrank', 'bus_factor']].head(10))
    
     
    repo_counts = df_wide['repo'].value_counts()
    for repo, count in repo_counts.items():
        print(f"   {repo}: {count} 行")
    


if __name__ == "__main__":
    main()