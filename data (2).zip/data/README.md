# 开源项目活跃度预测与风险评估平台

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)
[![OpenDigger](https://img.shields.io/badge/Data-OpenDigger-orange)](https://oss.x-lab.info/)

 一个大二的数据科学课程项目，用机器学习分析开源项目的活跃度和风险。

# 核心功能

- **数据采集**：从OpenDigger API自动获取开源项目指标
- **活跃度预测**：线性回归模型（R²=0.9796）预测项目未来活跃度
- **风险评估**：基于巴士因子(bus_factor)的项目风险分析
- **可视化**：交互式图表展示分析结果
- **系统集成**：与OpenSODA SQLBot无缝整合

## 项目结构
analysis_data:进行处理后的数据
import_data:将数据导入数据库，与SQLBot进行连接
notebooks:charts（六大图表）
          models(风险估计模型体系)
          results(关键指标数据)
analysis.ipynb:数据的导入，处理清晰，构建模型，验证模型，生成图表
test.data:官方数据引入
tests：增强器测试
demo_integration:增强器运行主程序
opensoda_enhancer:增强器代码
## 运行方式
直接运行增强器测试python demo_integration.py
启动jupyter notebook按单元格运行查看六大关键图表