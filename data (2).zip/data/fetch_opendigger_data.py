import requests
import json
import os
from datetime import datetime

class OpenDiggerTest:
    def __init__(self):
        self.base_url = "https://oss.x-lab.info"
        self.api_url = f"{self.base_url}/open_digger/github"
        
    def test_single_metric(self, repo_name: str, metric: str = "stars"):
         
        url = f"{self.api_url}/{repo_name}/{metric}.json"
        print(f"请求URL: {url}")
        
        try:
            response = requests.get(url, timeout=10)
            print(f"状态码: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"获取到数据，数据格式: {type(data)}")
                
               
                if isinstance(data, dict):
                    print(f"数据共有 {len(data)} 条记录")
                   
                    dates = sorted(data.keys())[-5:]
                    print("\n最新5个月的数据:")
                    for date in dates:
                        print(f"  {date}: {data[date]}")
                    
                    # 保存到JSON文件
                    self.save_to_json(repo_name, metric, data)
                else:
                    print(f"数据内容: {data}")
            else:
                print(f"请求失败: {response.text}")
                
        except Exception as e:
            print(f"发生错误: {e}")
    
    def save_to_json(self, repo_name: str, metric: str, data: dict):
        """保存数据到JSON文件"""
         
        os.makedirs("test_data", exist_ok=True)
        
        
        safe_repo_name = repo_name.replace('/', '_')
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"test_data/{safe_repo_name}_{metric}_{timestamp}.json"
          
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump({
                "repo": repo_name,
                "metric": metric,
                "fetch_time": datetime.now().isoformat(),
                "data": data
            }, f, ensure_ascii=False, indent=2)
        
        
        
        
        file_size = os.path.getsize(filename) / 1024  
        print(f"文件大小: {file_size:.2f} KB")


if __name__ == "__main__":
    
    
    tester = OpenDiggerTest()
    
   
    test_repos = [
        "torvalds/linux",  # Linux内核
        "pytorch/pytorch",  # PyTorch
        "vuejs/vue",  # Vue.js
        "facebook/react",  # React
    ]
     
    test_metrics = [
        # 核心活跃与影响力
        "openrank",           # 综合影响力指数
        "activity",           # 活跃度指数
        "attention",          # 受关注指数
        # 开发协作
        "code_change_lines_sum",      # 每月代码变更总行数
        "change_requests",            # PR总数
        "change_requests_accepted",   # 被合并的PR数
        "change_requests_reviews",    # PR review次数
        # 议题管理
        "issues_new",                 # 新开Issue数
        "issues_closed",              # 关闭Issue数
        "issue_response_time",        # Issue平均首次响应时间
        # 贡献者生态
        "participants",               # 活跃参与者数
        "new_contributors",           # 新贡献者数
        "inactive_contributors",      # 转为不活跃的贡献者数
        "bus_factor",                 # 巴士因子
        # 流行度
        "stars",
        "technical_fork",
    ]
    
    for repo in test_repos:
         
        for metric in test_metrics:
            print(f" 获取指标: {metric}")
            tester.test_single_metric(repo, metric)
            
        
    
     
