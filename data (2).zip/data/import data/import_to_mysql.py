import sqlite3
import pymysql
import pandas as pd
import time

 

 
 
try:
    sqlite_conn = sqlite3.connect('project_data.db')
    
    projects_df = pd.read_sql("SELECT * FROM projects", sqlite_conn)
    metrics_df = pd.read_sql("SELECT * FROM metrics", sqlite_conn)
    
    print(f" 读取成功:")
    print(f"   项目数: {len(projects_df)}")
    print(f"   指标记录: {len(metrics_df)}")
    
    print("\n项目列表:")
    for index, row in projects_df.iterrows():
        print(f"   {row['id']}. {row['name']}")
    
except Exception as e:
    print(f"读取SQLite失败: {e}")
    exit()

# 2. 连接到MySQL
print("连接到MySQL...")
try:
    mysql_conn = pymysql.connect(
        host='localhost',
        port=3306,
        user='opendigger',
        password='opendigger123',
        database='opendigger',
        charset='utf8mb4'
    )
    
    cursor = mysql_conn.cursor()
    print(" MySQL连接成功！")
    
except Exception as e:
    print(f"MySQL连接失败: {e}")
    sqlite_conn.close()
    exit()


print("\n 创建MySQL表...")
try:
    cursor.execute('DROP TABLE IF EXISTS metrics')
    cursor.execute('DROP TABLE IF EXISTS projects')
    print("清空旧表")
    
    cursor.execute('''
        CREATE TABLE projects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) UNIQUE NOT NULL,
            owner VARCHAR(255),
            repo VARCHAR(255)
        )
    ''')
    print("创建projects表")
    
    cursor.execute('''
        CREATE TABLE metrics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            project_id INT,
            date VARCHAR(20),
            metric VARCHAR(100),
            value DOUBLE,
            INDEX idx_project (project_id),
            INDEX idx_date (date),
            INDEX idx_metric (metric)
        )
    ''')
    print("创建metrics表")
    
except Exception as e:
    print(f"创建表出错: {e}")

 
project_map = {}   

for _, row in projects_df.iterrows():
    try:
        cursor.execute(
            "INSERT INTO projects (name, owner, repo) VALUES (%s, %s, %s)",
            (row['name'], row['owner'], row['repo'])
        )
        new_id = cursor.lastrowid
        project_map[row['id']] = new_id
        print(f"   ✓ {row['name']}")
    except Exception as e:
        print(f"   ✗ {row['name']}: {e}")

mysql_conn.commit()
print(f"导入 {len(projects_df)} 个项目")


print("\n导入指标数据")
total = len(metrics_df)
success = 0

for i, row in metrics_df.iterrows():
    try:
        new_project_id = project_map.get(row['project_id'])
        if new_project_id:
            cursor.execute(
                "INSERT INTO metrics (project_id, date, metric, value) VALUES (%s, %s, %s, %s)",
                (new_project_id, row['date'], row['metric'], row['value'])
            )
            success += 1
            
        
        if success % 500 == 0:
            mysql_conn.commit()
            print(f"  进度: {success}/{total}")
            
    except Exception as e:
        pass  

mysql_conn.commit()


 
cursor.execute("SELECT COUNT(*) FROM projects")
mysql_projects = cursor.fetchone()[0]

cursor.execute("SELECT COUNT(*) FROM metrics")
mysql_metrics = cursor.fetchone()[0]

print(f"导入完成:")
print(f"   MySQL项目数: {mysql_projects}")
print(f"   MySQL指标数: {mysql_metrics}")


cursor.close()
mysql_conn.close()
sqlite_conn.close()
 
 
 
print("   类型: MySQL")
print("   主机: localhost")
print("   端口: 3306")
print("   数据库: opendigger")
print("   用户名: opendigger")
print("   密码: opendigger123")
 
 