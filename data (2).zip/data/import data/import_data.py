
import json
import sqlite3
import pandas as pd
from datetime import datetime
import glob
import os

print("开始导入OpenDigger数据...")

 
db_file = 'project_data.db'
conn = sqlite3.connect(db_file)
cur = conn.cursor()

 
cur.execute('''
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE,
    owner TEXT,
    repo TEXT
)
''')

cur.execute('''
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY,
    project_id INTEGER,
    date TEXT,
    metric TEXT,
    value REAL,
    UNIQUE(project_id, date, metric)
)
''')

 
files = glob.glob("test_data/*.json")
print(f"找到 {len(files)} 个文件")

count = 0
for f in files:
    try:
        with open(f, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        repo = data.get('repo', 'unknown/unknown')
        metric_name = data.get('metric', 'unknown')
        metric_data = data.get('data', {})
        
        
        cur.execute("INSERT OR IGNORE INTO projects (name) VALUES (?)", (repo,))
        cur.execute("SELECT id FROM projects WHERE name = ?", (repo,))
        proj_id = cur.fetchone()[0]
         
        for date_str, value in metric_data.items():
            cur.execute('''
                INSERT OR REPLACE INTO metrics (project_id, date, metric, value)
                VALUES (?, ?, ?, ?)
            ''', (proj_id, date_str, metric_name, value))
            count += 1
        
        print(f"已处理: {repo} - {metric_name}")
        
    except Exception as e:
        print(f"错误 {f}: {e}")

conn.commit()

 
cur.execute("SELECT COUNT(*) FROM projects")
proj_count = cur.fetchone()[0]

cur.execute("SELECT COUNT(*) FROM metrics")
metric_count = cur.fetchone()[0]

print(f"\n导入完成！")
print(f"项目数: {proj_count}")
print(f"指标记录: {metric_count}")
print(f"数据库: {db_file} ({os.path.getsize(db_file)/1024/1024:.2f} MB)")

df = pd.read_sql("SELECT * FROM projects LIMIT 5", conn)
print(df)

conn.close()
print("\n可以连接到SQLBot了！")