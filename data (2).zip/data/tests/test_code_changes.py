# test_code_changes.py
from opensoda_enhancer import OpenSODAEnhancer

# 第三个SQLBot结果
sqlbot_results = {
    'name': '代码变更量排名',
    'data': {
        'pytorch/pytorch': 35131263,
        'facebook/react': 7681434,
        'torvalds/linux': 3959250,
        'vuejs/vue': 1230831
    }
}

enhancer = OpenSODAEnhancer()

print("测试增强器（生产力分析）")
enhanced = enhancer.enhance(sqlbot_results)

print(f"\n原始查询: {enhanced['original_query']}")
print(f"模型精度: R²={enhanced['model_info']['r2_score']}")

print("\n 生产力增强分析结果:")
for item in enhanced['enhanced_analysis']:
    print(f"  {item['project']}:")
    print(f"    代码变更: {item['code_changes']:,} 行")
    print(f"    生产力评估: {item['productivity_assessment']}")
    print(f"    重点关注: {item['focus_area']}")
    print()