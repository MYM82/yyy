# test_new_contributors.py
from opensoda_enhancer import OpenSODAEnhancer

# 第四个SQLBot结果
sqlbot_results = {
    'name': '新贡献者排名',
    'data': {
        'facebook/react': 27.196428571428573,
        'pytorch/pytorch': 16.60655737704918,
        'vuejs/vue': 10.606299212598426,
        'torvalds/linux': 1.0
    }
}

enhancer = OpenSODAEnhancer()

print("测试增强器（社区增长分析）")
enhanced = enhancer.enhance(sqlbot_results)

print(f"\n原始查询: {enhanced['original_query']}")
print(f"模型精度: R²={enhanced['model_info']['r2_score']}")

print("\n社区增长增强分析结果:")
for item in enhanced['enhanced_analysis']:
    print(f"  {item['project']}:")
    print(f"    新贡献者: {item['new_contributors']:.1f} 人/月")
    print(f"    增长评估: {item['growth_assessment']}")
    print(f"    增长策略: {item['growth_strategy']}")
    print()